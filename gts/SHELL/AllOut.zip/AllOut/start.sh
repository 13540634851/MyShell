#!/bin/sh
echo "start file"
echo "java -jar "$1 $2
java -jar Word.jar $1 $2
